#!/bin/bash

cd .gg && rm -f *