#!/bin/bash
ip="192.168.1.149"
pass="tootiya"
