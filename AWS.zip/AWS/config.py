# UNCOMMENT THE BELOW LINE FOR AUDIO Pipeline
#Cedge2 = 'f_t1_1'

# UNCOMMENT THE BELOW LINE FOR Facedetect Pipeline
#Cedge2 = 'f_t3'

# UNCOMMENT THE BELOW LINE FOR Image Pipeline
Cedge2 = 'f_t4'

# UNCOMMENT THE BELOW LINE FOR Scalar Pipeline
#Cedge2 = 'f_t0_1'

# UNCOMMENT THE BELOW LINE FOR Thumbnail Pipeline
#Cedge2 = 'f_t1'
